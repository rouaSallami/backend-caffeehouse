<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Addon;
use App\Http\Resources\AddonResource;

class AddonController extends Controller
{
    public function index()
{
    $addons = Addon::all();

    return response()->json(
        AddonResource::collection($addons)->resolve()
    );
}
}
